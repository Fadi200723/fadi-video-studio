/* Fadi Farm — كاتب ملفات MP4 قياسية (غير مجزأة، المعلومات في البداية) من مقاطع WebCodecs.
   يدعم فيديو H.264 وصوت AAC أو Opus. */
'use strict';

const MP4 = (() => {
  const te = new TextEncoder();
  const str = s => te.encode(s);
  const zeros = n => new Uint8Array(n);
  const u8 = a => new Uint8Array(a);
  function u16(...v) { const b = new Uint8Array(v.length * 2), d = new DataView(b.buffer); v.forEach((x, i) => d.setUint16(i * 2, x & 0xffff)); return b; }
  function u32(...v) { return u32a(v); }
  function u32a(arr) { const b = new Uint8Array(arr.length * 4), d = new DataView(b.buffer); for (let i = 0; i < arr.length; i++) d.setUint32(i * 4, arr[i] >>> 0); return b; }
  function box(type, ...parts) {
    let len = 8; for (const p of parts) len += p.length;
    const out = new Uint8Array(len); new DataView(out.buffer).setUint32(0, len); out.set(str(type), 4);
    let o = 8; for (const p of parts) { out.set(p, o); o += p.length; }
    return out;
  }
  const full = (type, version, flags, ...parts) => box(type, u8([version, (flags >> 16) & 255, (flags >> 8) & 255, flags & 255]), ...parts);
  const MATRIX = u32(0x00010000, 0, 0, 0, 0x00010000, 0, 0, 0, 0x40000000);

  function desc(tag, body) { return u8([tag, body.length, ...body]); }

  function esds(asc, bitrate) {
    const dsi = desc(0x05, [...asc]);
    const dcd = desc(0x04, [0x40, 0x15, 0, 0, 0, ...u32(bitrate, bitrate), ...dsi]);
    const es = desc(0x03, [0, 1, 0, ...dcd, ...desc(0x06, [0x02])]);
    return full('esds', 0, 0, es);
  }

  function audioEntry(a) {
    const head = [zeros(6), u16(1), zeros(8), u16(a.channels, 16, 0, 0), u32(a.sampleRate * 65536)];
    if (a.codec === 'opus') {
      const d = new Uint8Array(11), v = new DataView(d.buffer);
      v.setUint8(0, 0); v.setUint8(1, a.channels); v.setUint16(2, a.preSkip || 312); v.setUint32(4, a.inputRate || a.sampleRate); v.setInt16(8, 0); v.setUint8(10, 0);
      return box('Opus', ...head, box('dOps', d));
    }
    return box('mp4a', ...head, esds(a.asc, a.bitrate || 128000));
  }

  function videoEntry(v) {
    return box('avc1', zeros(6), u16(1), zeros(16), u16(v.width, v.height), u32(0x00480000, 0x00480000, 0), u16(1), zeros(32), u16(0x18, 0xffff), box('avcC', v.avcC));
  }

  /* يحوّل عينات المسار إلى: مدد (بمقياس المسار) + كتل (chunks) */
  function prepTrack(t, chunkSec) {
    const s = t.samples, n = s.length;
    const dts = s.map(x => Math.round(x.ts * t.timescale / 1e6));
    const durs = new Array(n);
    for (let i = 0; i < n - 1; i++) durs[i] = Math.max(1, dts[i + 1] - dts[i]);
    if (n) durs[n - 1] = Math.max(1, t.lastDur != null ? Math.round(t.lastDur * t.timescale) : (n > 1 ? durs[n - 2] : t.timescale / 30));
    const total = durs.reduce((a, b) => a + b, 0);
    const chunks = []; let cur = null;
    for (let i = 0; i < n; i++) {
      const time = dts[i] / t.timescale;
      if (!cur || time - cur.time >= chunkSec) { cur = { track: t, time, first: i, count: 0, size: 0 }; chunks.push(cur); }
      cur.count++; cur.size += s[i].data.length;
    }
    return Object.assign(t, { durs, total, chunks });
  }

  function stbl(t) {
    const stts = []; let last = -1;
    for (const d of t.durs) { if (d === last) stts[stts.length - 1][0]++; else { stts.push([1, d]); last = d; } }
    const stsc = []; t.chunks.forEach((c, i) => { if (!stsc.length || stsc[stsc.length - 1][1] !== c.count) stsc.push([i + 1, c.count, 1]); });
    const parts = [
      full('stsd', 0, 0, u32(1), t.kind === 'video' ? videoEntry(t) : audioEntry(t)),
      full('stts', 0, 0, u32(stts.length), u32a(stts.flat())),
    ];
    if (t.kind === 'video') { const keys = []; t.samples.forEach((x, i) => x.key && keys.push(i + 1)); parts.push(full('stss', 0, 0, u32(keys.length), u32a(keys))); }
    parts.push(
      full('stsc', 0, 0, u32(stsc.length), u32a(stsc.flat())),
      full('stsz', 0, 0, u32(0, t.samples.length), u32a(t.samples.map(x => x.data.length))),
      full('stco', 0, 0, u32(t.chunks.length), u32a(t.chunks.map(c => c.offset || 0))),
    );
    return box('stbl', ...parts);
  }

  function trak(t, id, movieDurMs) {
    const vid = t.kind === 'video';
    const durMovie = Math.round(t.total / t.timescale * 1000);
    return box('trak',
      full('tkhd', 0, 3, u32(0, 0, id, 0, durMovie), zeros(8), u16(0, 0, vid ? 0 : 0x0100, 0), MATRIX, u32(vid ? t.width * 65536 : 0, vid ? t.height * 65536 : 0)),
      box('mdia',
        full('mdhd', 0, 0, u32(0, 0, t.timescale, t.total), u16(0x55c4, 0)),
        full('hdlr', 0, 0, u32(0), str(vid ? 'vide' : 'soun'), zeros(12), str((vid ? 'VideoHandler' : 'SoundHandler') + '\0')),
        box('minf',
          vid ? full('vmhd', 0, 1, zeros(8)) : full('smhd', 0, 0, zeros(4)),
          box('dinf', full('dref', 0, 0, u32(1), full('url ', 0, 1))),
          stbl(t))));
  }

  /* tracks: [{kind:'video', samples:[{ts(µs), key, data}], width, height, avcC, timescale},
              {kind:'audio', codec:'aac'|'opus', samples, sampleRate, channels, asc, timescale}] */
  function build(tracks, { chunkSec = 0.5, mime = 'video/mp4' } = {}) {
    tracks = tracks.filter(t => t && t.samples.length).map(t => prepTrack(t, chunkSec));
    const order = tracks.flatMap(t => t.chunks).sort((a, b) => a.time - b.time || (a.track.kind === 'video' ? -1 : 1));
    const ftyp = box('ftyp', str('isom'), u32(512), str('isomiso2avc1mp41'));
    const durMs = Math.max(...tracks.map(t => Math.round(t.total / t.timescale * 1000)));
    const moovOf = () => box('moov',
      full('mvhd', 0, 0, u32(0, 0, 1000, durMs), u32(0x00010000), u16(0x0100, 0), zeros(8), MATRIX, zeros(24), u32(tracks.length + 1)),
      ...tracks.map((t, i) => trak(t, i + 1, durMs)));
    // تمريرة أولى لمعرفة حجم moov، ثم حساب مواقع الكتل
    let moov = moovOf();
    let off = ftyp.length + moov.length + 8;
    for (const c of order) { c.offset = off; off += c.size; }
    moov = moovOf();
    const mdatSize = off - ftyp.length - moov.length;
    if (off > 0xffffffff) throw new Error('الفيديو أكبر من 4GB');
    const parts = [ftyp, moov, u32(mdatSize), str('mdat')];
    for (const c of order) for (let i = c.first; i < c.first + c.count; i++) parts.push(c.track.samples[i].data);
    return new Blob(parts, { type: mime });
  }

  return { build };
})();

if (typeof module !== 'undefined') module.exports = MP4;
