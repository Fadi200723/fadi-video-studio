/* Fadi Farm — استوديو الصورة المصغرة: خلفية مولّدة بالذكاء الاصطناعي أو من اللقطات + تصميمات يوتيوب احترافية (بدون شعار) */
'use strict';

const Thumb = (() => {
  const W = 1280, H = 720;
  const st = { custom: null, source: 'flow', layout: 'hero', color: '#FFD23F', idx: 0, idx2: 1, ai: null, aiBusy: false, promo: null, drawing: null };
  const FONT = n => `400 ${n}px "Lalezar", "IBM Plex Sans Arabic", sans-serif`;

  const scenesWithMedia = () => App.scenes.filter(s => s.blobKey);

  async function frameOf(scene, at = 0.35) {
    const b = await Store.getBlob(scene.blobKey);
    if (!b) return null;
    const el = await Media.element(b, scene.asset.type);
    if (scene.asset.type === 'video') {
      await new Promise(r => { el.onseeked = r; try { el.currentTime = Math.min((el.duration || 2) * at, 6); } catch { r(); } setTimeout(r, 3000); });
    }
    return el;
  }
  const dims = el => [el.videoWidth || el.naturalWidth || el.width, el.videoHeight || el.naturalHeight || el.height];

  function cover(g, el, x, y, w, h, focusX = 0.5) {
    const [ew, eh] = dims(el); if (!ew) return;
    const k = Math.max(w / ew, h / eh), dw = ew * k, dh = eh * k;
    g.drawImage(el, x + (w - dw) * focusX, y + (h - dh) / 2, dw, dh);
  }

  /* ---------- الخلفيات ---------- */
  /* وصف احترافي طويل للصورة المصغرة (من Gemini، أو يُبنى محلياً إذا تعذّر Gemini) */
  /* شخصية فادي: شاب عربي يظهر في الصورة المصغرة بتعبير مبالغ فيه */
  const HOST = 'the channel host "Fadi": a handsome young Arab man around 25 years old with North African Arab features, short styled black hair, a neat short beard, light olive skin, wearing a modern casual jacket, waist-up in the foreground on one side of the frame, with a hugely exaggerated expressive reaction that matches the story (wide eyes, raised eyebrows, open mouth, pointing at the subject), sharp face, perfectly lit';

  function subjects() {
    const en = [...new Set(App.scenes.flatMap(s => s.kw).filter(w => /^[a-z ]+$/i.test(w)))].slice(0, 3);
    if (!en.length) en.push(Channel.id === 'farm' ? 'Egyptian baladi chickens' : 'a dramatic breaking news scene');
    return en;
  }

  function localPrompt() {
    const subj = subjects(), farm = Channel.id === 'farm', glow = farm ? 'yellow' : 'electric blue';
    const title = ($('#thumbTitle')?.value || App.projName || '').trim(), phrase = title.split(/\s+/).slice(0, 2).join(' ') || Channel.cur.name;
    const vs = st.layout === 'vs', host = Settings.get().thumbHost === true;
    const story = App.scenes.slice(0, 3).map(s => s.text).join(' ').slice(0, 160);
    return [
      `A highly clickable YouTube thumbnail, 16:9 landscape, 1920x1080, about: ${story}.`,
      vs ? `Split composition: on the left ${subj[0]}, on the right ${subj[1] || subj[0]}, facing each other like rivals, both large in frame, a glowing diagonal divider between them.`
         : `Hero shot: a dramatic close-up of ${subj.join(', ')}, the subject fills the ${host ? 'center-right' : 'left two thirds'} of the frame with an expressive moment that tells the story.`,
      host ? `On the left side: ${HOST}.` : '',
      `Setting: ${Channel.cur.setting}, softly blurred background.`,
      `Camera: 85mm lens, low angle, shallow depth of field, tack-sharp details.`,
      `Lighting: dramatic rim light, high contrast, cinematic volumetric glow.`,
      `Color grading: vivid saturated colors, ${farm ? 'warm orange and teal' : 'deep blue and white with neon accents'} contrast, punchy and bright.`,
      `Text: the Arabic phrase "${phrase}" written once in huge bold 3D Arabic letters, white fill, thick black outline and a ${glow} glow, placed on the ${host ? 'top' : 'right'} third, perfectly legible.`,
      `Ultra realistic, 8k, sharp focus, professional YouTube thumbnail style, no logos, no watermark, no other text.`,
    ].filter(Boolean).join(' ');
  }

  function autoPrompt() {
    let base = st.promo?.thumbPrompt && st.promo.thumbPrompt.length > 300 ? st.promo.thumbPrompt : localPrompt();
    if (Settings.get().thumbHost === true && !/Fadi/.test(base)) base += ` Also include ${HOST}.`;
    if (Settings.get().flowText === false) base = base.replace(/Text:[^.]*\.[^.]*\./i, '').replace(/Include ONE short bold Arabic phrase[^.]*\./i, '') + ' No text at all.';
    if (!/16:9/.test(base)) base += ' Format: YouTube thumbnail, 16:9 widescreen landscape, 1920x1080.';
    return base;
  }
  /* الوصف المعدّل يدوياً له الأولوية */
  function prompt() { return (st.custom || '').trim() || autoPrompt(); }
  function showPrompt() { const el = $('#thumbPromptText'); if (el && document.activeElement !== el) el.value = prompt(); $('#thumbPromptReset').hidden = !st.custom; }

  async function saved() {
    if (st.ai) return st.ai;
    try { const b = await Store.getBlob('thumb-ai'); if (b) return (st.ai = await createImageBitmap(b)); } catch {}
    return null;
  }

  async function setImage(blob) {
    await Store.putBlob('thumb-ai', blob).catch(() => {});
    st.ai = await createImageBitmap(blob);
    await draw();
  }

  /* Google Flow: ينسخ الوصف ويفتح Flow، ثم يلتقط الصورة المنزّلة تلقائياً */
  async function viaFlow() {
    if (!NATIVE) { await copyText(prompt()); window.open(Capture.URLS.flow, '_blank'); return toast('نُسخ الوصف. بعد تنزيل الصورة من Flow اضغط «خلفية من المعرض»', '', 7000); }
    if (!(await Capture.prepare())) return;
    Capture.start({ kind: 'image', action: 'thumb', label: 'صورة الصورة المصغرة من Google Flow', onFound: f => fromFlow(f) });
    await Capture.copyOpen(prompt(), 'flow');
    toast('نُسخ وصف الصورة (16:9). في Flow: الصقه، اختر «صورة» واصنعها، ثم نزّلها', '', 8000);
  }

  async function fromFlow(f) {
    if (App.view !== 'publish') go('publish');
    setSource('flow');
    if (Settings.get().flowText !== false) setLayout('clean');     // الصورة فيها الجملة من Flow: لا نكرر الكتابة
    st.layoutSet = true;
    await setImage(f);
    toast('أُضيفت صورة Google Flow. اختر «بطل» أو «مقارنة» إذا أردت كتابة التطبيق فوقها');
  }

  async function viaGemini() {
    try { await setImage(await AI.image(prompt())); }
    catch (e) {
      const msg = /حد|limit|quota|429/i.test(e.message) ? 'حسابك المجاني في Google AI Studio لا يسمح بتوليد الصور (الحد صفر). استخدم Google Flow' : e.message;
      toast(msg, 'err', 8000);
    }
  }

  async function background(g) {
    if (st.source !== 'footage') {
      const bmp = await saved();
      if (bmp) { grade(g, () => cover(g, bmp, 0, 0, W, H, 0.5)); return true; }
    }
    const list = scenesWithMedia();
    if (!list.length) { const gr = g.createLinearGradient(0, 0, W, H); gr.addColorStop(0, '#2b4a1f'); gr.addColorStop(1, '#0e1a0b'); g.fillStyle = gr; g.fillRect(0, 0, W, H); return false; }
    const pick = n => list[((n % list.length) + list.length) % list.length];
    if (st.layout === 'vs') {
      const [a, b] = await Promise.all([frameOf(pick(st.idx)), frameOf(pick(st.idx + 1 === st.idx2 ? st.idx2 : st.idx + Math.max(1, Math.floor(list.length / 2))), 0.5)]);
      grade(g, () => {
        g.save(); g.beginPath(); g.moveTo(0, 0); g.lineTo(W * 0.56, 0); g.lineTo(W * 0.44, H); g.lineTo(0, H); g.closePath(); g.clip();
        if (b) cover(g, b, 0, 0, W * 0.56, H); g.restore();
        g.save(); g.beginPath(); g.moveTo(W * 0.56, 0); g.lineTo(W, 0); g.lineTo(W, H); g.lineTo(W * 0.44, H); g.closePath(); g.clip();
        if (a) cover(g, a, W * 0.44, 0, W * 0.56, H); g.restore();
      });
      // خط الفصل المائل
      g.save(); g.strokeStyle = '#fff'; g.lineWidth = 14; g.beginPath(); g.moveTo(W * 0.56, -10); g.lineTo(W * 0.44, H + 10); g.stroke(); g.restore();
      [a, b].forEach(e => e && URL.revokeObjectURL(e.src));
    } else {
      const el = await frameOf(pick(st.idx));
      if (el) { grade(g, () => cover(g, el, 0, 0, W, H, 0.35)); URL.revokeObjectURL(el.src); }
    }
    return true;
  }

  // تحسين الألوان: تشبّع وتباين أعلى كما في صور يوتيوب
  function grade(g, fn) { g.save(); g.filter = 'saturate(1.35) contrast(1.12) brightness(1.04)'; fn(); g.restore(); }

  /* ---------- النص ---------- */
  function fitFont(g, lines, maxW, start, min = 60) {
    let fs = start; g.font = FONT(fs);
    while (Math.max(...lines.map(l => g.measureText(l).width)) > maxW && fs > min) { fs -= 4; g.font = FONT(fs); }
    return fs;
  }

  function strokeText(g, text, x, y, fs, fill, { stroke = '#000', glow = true } = {}) {
    g.save();
    if (glow) { g.shadowColor = 'rgba(0,0,0,.65)'; g.shadowBlur = fs * 0.25; g.shadowOffsetY = fs * 0.06; }
    g.lineJoin = 'round'; g.miterLimit = 2;
    g.lineWidth = fs * 0.2; g.strokeStyle = stroke; g.strokeText(text, x, y);
    g.shadowColor = 'transparent';
    g.fillStyle = fill; g.fillText(text, x, y);
    g.restore();
  }

  function pill(g, text, x, y, fs, bg, fg, align = 'right', tilt = -0.04) {
    g.save();
    g.font = FONT(fs);
    const w = g.measureText(text).width, padX = fs * 0.32, padY = fs * 0.12, h = fs * 1.12;
    const left = align === 'right' ? x - w - padX * 2 : align === 'center' ? x - w / 2 - padX : x;
    g.translate(left + (w + padX * 2) / 2, y); g.rotate(tilt);
    g.shadowColor = 'rgba(0,0,0,.55)'; g.shadowBlur = 24; g.shadowOffsetY = 8;
    g.fillStyle = bg; roundRect(g, -(w + padX * 2) / 2, -h / 2 - padY, w + padX * 2, h + padY * 2, fs * 0.18); g.fill();
    g.shadowColor = 'transparent';
    g.lineWidth = 6; g.strokeStyle = '#000'; g.stroke();
    g.fillStyle = fg; g.textAlign = 'center'; g.textBaseline = 'middle'; g.direction = 'rtl';
    g.fillText(text, 0, fs * 0.04);
    g.restore();
  }

  function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }

  function arrow(g, x1, y1, x2, y2, color) {
    g.save();
    const cx = (x1 + x2) / 2, cy = Math.min(y1, y2) - 90;
    const path = () => { g.beginPath(); g.moveTo(x1, y1); g.quadraticCurveTo(cx, cy, x2, y2); };
    g.lineCap = 'round';
    g.shadowColor = 'rgba(0,0,0,.5)'; g.shadowBlur = 16;
    g.lineWidth = 30; g.strokeStyle = '#fff'; path(); g.stroke();
    g.shadowColor = 'transparent';
    g.lineWidth = 18; g.strokeStyle = color; path(); g.stroke();
    const ang = Math.atan2(y2 - cy, x2 - cx), L = 54;
    const head = () => { g.beginPath(); g.moveTo(x2 + Math.cos(ang) * 18, y2 + Math.sin(ang) * 18); g.lineTo(x2 - Math.cos(ang - 0.55) * L, y2 - Math.sin(ang - 0.55) * L); g.lineTo(x2 - Math.cos(ang + 0.55) * L, y2 - Math.sin(ang + 0.55) * L); g.closePath(); };
    g.lineJoin = 'round'; g.lineWidth = 12; g.strokeStyle = '#fff'; head(); g.stroke(); g.fillStyle = color; head(); g.fill();
    g.restore();
  }

  function splitTitle(title, maxLines = 2) {
    const w = title.split(/\s+/).filter(Boolean);
    if (w.length <= 2 || maxLines === 1) return [title];
    const mid = Math.ceil(w.length / 2);
    return [w.slice(0, mid).join(' '), w.slice(mid).join(' ')];
  }

  /* ---------- التصميمات ---------- */
  function layoutHero(g, title, hi) {
    // تظليل جهة النص (اليمين) + إطار سينمائي
    const gr = g.createLinearGradient(W, 0, W * 0.3, 0);
    gr.addColorStop(0, 'rgba(0,0,0,.82)'); gr.addColorStop(0.55, 'rgba(0,0,0,.45)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(0, 0, W, H);
    vignette(g);
    const lines = splitTitle(title);
    g.direction = 'rtl'; g.textAlign = 'right'; g.textBaseline = 'middle';
    const fs = fitFont(g, lines, W * 0.5, lines.length > 1 ? 150 : 190);
    const x = W * 0.955, y0 = H * 0.5 - (lines.length - 1) * fs * 0.62;
    lines.forEach((l, i) => {
      const y = y0 + i * fs * 1.24;
      if (hi && l.includes(hi)) pill(g, l, x, y, fs, st.color, '#111', 'right', i % 2 ? 0.03 : -0.035);
      else strokeText(g, l, x, y, fs, '#fff');
    });
    const tw = Math.max(...lines.map(l => { g.font = FONT(fs); return g.measureText(l).width; }));
    arrow(g, x - tw - 40, y0 + (lines.length - 1) * fs * 0.62 + 20, W * 0.38, H * 0.62, st.color);
  }

  function layoutVs(g, title, hi) {
    vignette(g);
    const parts = title.replace(/[؟?]/g, '').split(/\s+(?:ولا|أو|او|vs|VS)\s+/);
    const right = (parts[0] || title).trim(), left = (parts[1] || '').trim();
    // شارة المنتصف
    g.save();
    g.shadowColor = 'rgba(0,0,0,.6)'; g.shadowBlur = 30;
    g.fillStyle = st.color; g.beginPath(); g.arc(W / 2, H * 0.5, 118, 0, Math.PI * 2); g.fill();
    g.shadowColor = 'transparent'; g.lineWidth = 12; g.strokeStyle = '#fff'; g.stroke();
    g.fillStyle = '#111'; g.font = FONT(left ? 120 : 92); g.textAlign = 'center'; g.textBaseline = 'middle'; g.direction = 'rtl';
    g.fillText(left ? 'ولا' : 'VS', W / 2, H * 0.5 + 6);
    g.restore();
    // عنوانا الطرفين أسفل كل نصف
    const lab = (t, x) => { g.font = FONT(120); const fs = fitFont(g, [t], W * 0.38, 130); pill(g, t, x, H * 0.84, fs, t === hi || (hi && t.includes(hi)) ? st.color : '#fff', '#111', 'center', x > W / 2 ? 0.035 : -0.035); };
    if (left) { lab(right, W * 0.76); lab(left, W * 0.24); }
    else {
      g.direction = 'rtl'; g.textAlign = 'center'; g.textBaseline = 'middle';
      const lines = splitTitle(title, 1), fs = fitFont(g, lines, W * 0.9, 140);
      strokeText(g, lines[0], W / 2, H * 0.84, fs, st.color);
    }
    // علامة استفهام كبيرة
    if (/[؟?]/.test(title)) { g.save(); g.font = FONT(200); g.textAlign = 'center'; g.direction = 'rtl'; g.textBaseline = 'middle'; strokeText(g, '؟', W * 0.92, H * 0.24, 200, st.color); g.restore(); }
  }

  function layoutFrame(g, title, hi) {
    vignette(g);
    const band = H * 0.3;
    const gr = g.createLinearGradient(0, H - band * 1.6, 0, H);
    gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.88)');
    g.fillStyle = gr; g.fillRect(0, H - band * 1.6, W, band * 1.6);
    g.direction = 'rtl'; g.textAlign = 'center'; g.textBaseline = 'middle';
    const lines = [title], fs = fitFont(g, lines, W * 0.88, 170);
    if (hi && title.includes(hi)) {
      // كلمة مميزة داخل العنوان بلون مختلف
      const parts = title.split(hi), y = H - band * 0.52;
      g.font = FONT(fs);
      const total = g.measureText(title).width; let x = W / 2 + total / 2;
      const seg = (t, color) => { if (!t) return; g.font = FONT(fs); const w = g.measureText(t).width; g.textAlign = 'right'; strokeText(g, t, x, y, fs, color); x -= w; };
      seg(parts[0], '#fff'); seg(hi, st.color); seg(parts.slice(1).join(hi), '#fff');
    } else strokeText(g, title, W / 2, H - band * 0.52, fs, st.color);
    // إطار ملون
    g.save(); g.lineWidth = 22; g.strokeStyle = st.color; g.strokeRect(11, 11, W - 22, H - 22);
    g.lineWidth = 4; g.strokeStyle = '#fff'; g.strokeRect(26, 26, W - 52, H - 52); g.restore();
  }

  function layoutClean(g) { vignette(g); }

  function vignette(g) {
    const vg = g.createRadialGradient(W / 2, H / 2, H * 0.35, W / 2, H / 2, W * 0.72);
    vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,.5)');
    g.fillStyle = vg; g.fillRect(0, 0, W, H);
  }

  /* ---------- الرسم ---------- */
  async function draw() {
    const run = (st.drawing || Promise.resolve()).then(async () => {
      const cv = $('#thumbCv'); if (!cv) return;
      const off = document.createElement('canvas'); off.width = W; off.height = H;
      const g = off.getContext('2d');
      try { await document.fonts.load(FONT(120)); } catch {}
      $('#thumbBusy').hidden = false;
      try {
        await background(g);
        const title = ($('#thumbTitle').value || st.promo?.thumbTitle || App.projName || 'فادي فارم').trim();
        const hi = ($('#thumbHi').value || st.promo?.thumbHighlight || '').trim();
        ({ hero: layoutHero, vs: layoutVs, frame: layoutFrame, clean: layoutClean })[st.layout](g, title, hi);
        cv.getContext('2d').drawImage(off, 0, 0);
      } finally { $('#thumbBusy').hidden = true; }
    });
    st.drawing = run.catch(() => {});
    return run;
  }

  function setSource(v) {
    st.source = v;
    $$('#thumbSource button').forEach(b => b.classList.toggle('on', b.dataset.v === v));
    $('#thumbNav').hidden = v !== 'footage';
    $('#thumbRegen').hidden = v === 'footage';
    $('#thumbRegen').textContent = v === 'gemini' ? 'اصنع الخلفية بـ Gemini' : 'اصنع الخلفية بـ Google Flow';
    showPrompt();
  }
  function setLayout(v) { st.layout = v; $$('#thumbLayout button').forEach(b => b.classList.toggle('on', b.dataset.v === v)); }

  async function enter(promo) {
    if (st.custom == null) { try { st.custom = (await Store.get('thumb-prompt')) || ''; } catch { st.custom = ''; } }
    st.promo = promo || st.promo;
    if (st.promo) {
      if (!$('#thumbTitle').value) $('#thumbTitle').value = st.promo.thumbTitle || '';
      if (!$('#thumbHi').value) $('#thumbHi').value = st.promo.thumbHighlight || '';
      if (!st.layoutSet) setLayout(st.promo.thumbLayout || 'hero');
      const k = scenesWithMedia().findIndex(s => s === App.scenes[st.promo.thumbScene]);
      if (k >= 0 && !st.idxSet) st.idx = k;
    }
    setSource(st.source);
    draw().catch(() => {});
  }

  function reset() { st.custom = ''; Store.set('thumb-prompt', '').catch(() => {}); st.ai = null; st.promo = null; st.layoutSet = false; st.idxSet = false; Store.delBlob('thumb-ai').catch(() => {}); }

  function save(share) {
    $('#thumbCv').toBlob(b => { if (b) saveFile(b, `${safeName()}-thumbnail.jpg`, { share }).catch(e => toast(e.message, 'err')); }, 'image/jpeg', 0.93);
  }

  function bind() {
    Capture.register('thumb', f => fromFlow(f));
    $('#flowText').checked = Settings.get().flowText !== false;
    $('#flowText').onchange = e => { Settings.set({ flowText: e.target.checked }); showPrompt(); };
    $('#thumbHost').checked = Settings.get().thumbHost === true;
    $('#thumbHost').onchange = e => { Settings.set({ thumbHost: e.target.checked }); st.custom = ''; Store.set('thumb-prompt', '').catch(() => {}); showPrompt(); };
    $('#thumbPromptText').addEventListener('input', e => { st.custom = e.target.value; Store.set('thumb-prompt', st.custom).catch(() => {}); $('#thumbPromptReset').hidden = false; });
    $('#thumbPromptReset').onclick = () => { st.custom = ''; Store.set('thumb-prompt', '').catch(() => {}); $('#thumbPromptText').value = autoPrompt(); $('#thumbPromptReset').hidden = true; toast('رجع الوصف التلقائي'); };
    $('#thumbCopyPrompt').onclick = async () => { if (await copyText(prompt())) toast('نُسخ الوصف'); };
    $('#thumbSource').addEventListener('click', e => { const b = e.target.closest('[data-v]'); if (!b) return; setSource(b.dataset.v); draw(); });
    $('#thumbLayout').addEventListener('click', e => { const b = e.target.closest('[data-v]'); if (!b) return; st.layoutSet = true; setLayout(b.dataset.v); showPrompt(); draw(); });
    $('#thumbPrev').onclick = () => { st.idx--; st.idxSet = true; draw(); };
    $('#thumbNext').onclick = () => { st.idx++; st.idxSet = true; draw(); };
    $('#thumbRegen').onclick = async () => {
      const b = $('#thumbRegen'); b.disabled = true;
      try { if (st.source === 'gemini') { b.textContent = 'Gemini يرسم…'; await viaGemini(); } else await viaFlow(); }
      finally { b.disabled = false; setSource(st.source); }
    };
    $('#thumbGallery').onclick = async () => {
      let f = null;
      if (NATIVE) f = await pickFromGallery('image').catch(e => { toast(e.message, 'err'); return null; });
      else { const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; f = await new Promise(r => { i.onchange = () => r(i.files[0] || null); i.click(); }); }
      if (f) { if (st.source === 'footage') setSource('flow'); await setImage(f); }
    };
    let t; ['#thumbTitle', '#thumbHi'].forEach(sel => $(sel).addEventListener('input', () => { clearTimeout(t); t = setTimeout(draw, 300); }));
    $('#thumbColors').addEventListener('click', e => { const c = e.target.closest('[data-c]'); if (!c) return; st.color = c.dataset.c; $$('#thumbColors [data-c]').forEach(x => x.classList.toggle('on', x === c)); draw(); });
    $('#thumbSave').onclick = () => save(false);
    $('#thumbShare').onclick = () => save(true);
  }

  return { enter, bind, draw, reset };
})();
