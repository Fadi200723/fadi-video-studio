/* Fadi — طبقة الذكاء الاصطناعي (Gemini). يمكن استبدالها بمزوّد آخر بتغيير هذا الملف فقط. */
'use strict';

const AI = (() => {
  const API = 'https://generativelanguage.googleapis.com/v1beta/models/';

  /* ---------- الشبكة: تنظيم الطلبات + قراءة أخطاء الحصة + بدائل النماذج ---------- */
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const Net = { last: 0, q: Promise.resolve() };
  function pace(gap = 4300) {
    const run = Net.q.then(async () => { const w = Net.last + gap - Date.now(); if (w > 0) await sleep(w); Net.last = Date.now(); });
    Net.q = run.catch(() => {});
    return run;
  }
  const badKey = () => 'ff.badModels.' + new Date().toISOString().slice(0, 10);
  const bad = () => { try { return new Set(JSON.parse(localStorage.getItem(badKey()) || '[]')); } catch { return new Set(); } };
  function markBad(m) { const b = bad(); b.add(m); try { localStorage.setItem(badKey(), JSON.stringify([...b])); } catch {} }

  function quotaInfo(d) {
    const det = d?.error?.details || [], msg = d?.error?.message || '';
    const qf = det.find(x => /QuotaFailure/.test(x['@type'] || '')), ri = det.find(x => /RetryInfo/.test(x['@type'] || ''));
    const v = qf?.violations?.[0] || {}, id = `${v.quotaId || ''} ${v.quotaMetric || ''}`;
    return {
      perDay: /PerDay/i.test(id) || /per.?day/i.test(msg),
      zero: /limit:\s*0\b/.test(msg) || String(v.quotaValue) === '0',
      retry: parseFloat(ri?.retryDelay) || parseFloat((msg.match(/retry in ([\d.]+)\s*s/i) || [])[1]) || 0,
    };
  }

  function errMsg(status, d) {
    const m = d?.error?.message || '', st = d?.error?.status || '';
    if (/API_KEY_INVALID|API key not valid/i.test(m + st)) return 'مفتاح Gemini غير صالح. انسخه من جديد من aistudio.google.com/app/apikey';
    if (/SERVICE_DISABLED|has not been used|is disabled/i.test(m)) return 'المفتاح من Google Cloud وخدمة Gemini غير مفعّلة فيه. أنشئ مفتاحاً من aistudio.google.com/app/apikey';
    if (/location is not supported|User location/i.test(m)) return 'Gemini غير متاح من موقعك الحالي';
    if (status === 403) return 'المفتاح لا يملك صلاحية: ' + m.slice(0, 140);
    if (status === 404) return 'النموذج غير متاح لهذا المفتاح';
    if (status === 429) { const q = quotaInfo(d); return q.zero ? 'هذا النموذج بلا حصة مجانية في حسابك' : q.perDay ? 'انتهى الحد اليومي المجاني لهذا النموذج' : 'Gemini مشغول (حد الطلبات في الدقيقة)'; }
    if (status === 400) return 'رفض Gemini الطلب: ' + m.slice(0, 160);
    if (status >= 500) return 'خوادم Gemini مشغولة. أعد المحاولة بعد قليل';
    return `خطأ Gemini (${status})`;
  }

  let waitToast = 0;
  function waiting(sec) { if (Date.now() - waitToast > 20000) { waitToast = Date.now(); toast(`Gemini يطلب انتظار ${Math.ceil(sec)} ثانية (حد الدقيقة). سأكمل تلقائياً…`, '', 6000); } }

  /* يرسل الطلب لأول نموذج متاح؛ عند نفاد حصة نموذج ينتقل للتالي. models: قائمة بالأولوية */
  async function send(models, makeReq, { signal, gap = 4300 } = {}) {
    const key = Settings.get().keys.gemini?.trim();
    if (!key) throw new Error('أضف مفتاح Gemini من الإعدادات أولاً');
    const list = [...new Set(models.filter(Boolean))], b = bad();
    const order = [...list.filter(m => !b.has(m)), ...list.filter(m => b.has(m))];
    let last = null, quotaHit = null;
    for (const model of order) {
      for (let a = 0; a < 4; a++) {
        await pace(gap);
        let r, d;
        try {
          const { url, body } = makeReq(model);
          r = await fetch(url, { method: 'POST', signal, headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key }, body: JSON.stringify(body) });
          d = await r.json().catch(() => ({}));
        } catch (e) {
          if (e.name === 'AbortError') throw e;
          if (a < 2) { await sleep(2000 * (a + 1)); continue; }
          throw new Error('تعذّر الاتصال بـ Gemini. تحقق من الإنترنت');
        }
        if (r.ok) return { d, model };
        last = { status: r.status, d };
        if (r.status === 429) {
          const q = quotaInfo(d);
          if (q.zero || q.perDay) { markBad(model); quotaHit = q; break; }          // جرّب نموذجاً آخر
          const w = Math.min(65, q.retry || 15 * (a + 1)); waiting(w); await sleep(w * 1000 + 500); continue;
        }
        if (r.status >= 500 && a < 2) { await sleep(3000 * (a + 1)); continue; }
        if (r.status === 404 || (r.status === 400 && /model|not found|not supported/i.test(d?.error?.message || ''))) { markBad(model); break; }
        throw new Error(errMsg(r.status, d));
      }
    }
    if (quotaHit) throw new Error(quotaHit.perDay ? 'انتهت حصة Gemini المجانية لهذا اليوم في كل النماذج المتاحة. تتجدد غداً' : 'مفتاحك لا يملك حصة مجانية لهذه النماذج. أنشئ المفتاح من aistudio.google.com/app/apikey');
    throw new Error(last ? errMsg(last.status, last.d) : 'تعذّر الوصول لأي نموذج Gemini');
  }

  const TEXT_MODELS = () => [Settings.get().geminiModel, 'gemini-flash-lite-latest', 'gemini-3.5-flash-lite', 'gemini-flash-latest', 'gemini-3.6-flash', 'gemini-3.1-flash-lite', 'gemini-3.8-flash'];

  async function call(parts, { signal } = {}) {
    for (let a = 0; a < 2; a++) {
      const { d } = await send(TEXT_MODELS(), model => ({
        url: API + encodeURIComponent(model) + ':generateContent',
        body: { contents: [{ role: 'user', parts }], generationConfig: { temperature: 0.3, responseMimeType: 'application/json' } },
      }), { signal });
      const c = d.candidates?.[0];
      const text = (c?.content?.parts || []).map(p => p.text || '').join('').trim();
      if (!text) { if (a === 0) continue; throw new Error('لم يُرجع Gemini نتيجة (' + (c?.finishReason || d.promptFeedback?.blockReason || 'رد فارغ') + ')'); }
      try { return JSON.parse(text.replace(/^```(?:json)?\s*|\s*```$/g, '')); }
      catch { if (a === 0) continue; throw new Error('ردّ Gemini غير منسّق، أعد المحاولة'); }
    }
  }

  /* تحويل الصوت إلى WAV أحادي 16kHz ثم تقطيعه عند لحظات الصمت */
  async function audioChunks(buf, chunkSec = 240) {
    const sr = 16000, len = Math.ceil(buf.duration * sr);
    const off = new OfflineAudioContext(1, len, sr);
    const src = off.createBufferSource(); src.buffer = buf; src.connect(off.destination); src.start();
    const data = (await off.startRendering()).getChannelData(0);
    const cuts = [0];
    const win = Math.floor(sr * 0.05);
    for (let b = chunkSec * sr; b < data.length - sr * 20; b += chunkSec * sr) {
      let best = b, bestE = Infinity;
      for (let x = b - 8 * sr; x < b + 8 * sr; x += win) {
        let e = 0; for (let k = 0; k < win; k += 4) e += data[x + k] * data[x + k];
        if (e < bestE) { bestE = e; best = x; }
      }
      cuts.push(best); b = best;
    }
    cuts.push(data.length);
    const out = [];
    for (let i = 0; i < cuts.length - 1; i++) {
      const seg = data.subarray(cuts[i], cuts[i + 1]);
      out.push({ offset: cuts[i] / sr, dur: seg.length / sr, blob: wav(seg, sr) });
    }
    return out;
  }

  function wav(f32, sr) {
    const b = new ArrayBuffer(44 + f32.length * 2), v = new DataView(b);
    const w = (o, s) => [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
    w(0, 'RIFF'); v.setUint32(4, 36 + f32.length * 2, true); w(8, 'WAVE'); w(12, 'fmt ');
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true); v.setUint32(24, sr, true);
    v.setUint32(28, sr * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, f32.length * 2, true);
    for (let i = 0; i < f32.length; i++) { const x = Math.max(-1, Math.min(1, f32[i])); v.setInt16(44 + i * 2, x < 0 ? x * 0x8000 : x * 0x7fff, true); }
    return new Blob([b], { type: 'audio/wav' });
  }

  const b64 = blob => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = rej; r.readAsDataURL(blob); });

  function guide(target) {
    const s = Settings.get();
    return `Channel context: ${s.context || 'general'}.
For each scene also give 3 to 5 visual search keywords IN ENGLISH for stock footage sites (Pexels, Pixabay, Wikimedia, NASA). Keywords must describe concrete filmable things: subjects, objects, places, actions, mood of the shot (e.g. ${Channel.cur.examples}). Most specific keyword first, short phrases of 1 to 4 words, no abstract words.
${Channel.id === 'farm' ? `Also give "subject": the single main animal, object or place of the scene in English, 1 or 2 words (e.g. "chicken", "turkey", "duck", "chicken coop", "farmer"). If the narration talks about a specific animal breed or type (local/baladi chickens, turkeys, ducks, geese, rabbits, goats), name that animal in the subject and in the first keyword, because stock sites are searched with it.
When the scene is abstract (greetings, "subscribe", opinions), still give keywords that show the channel's world (e.g. "chickens free range farm", "farmer feeding chickens").`
: `Also give "subject": the main visual subject of the scene in English, 1 to 3 words (a place, person type, object or event, e.g. "Algiers street", "football fans", "smartphone", "news studio"). Name real places and objects literally (city, stadium, product type) because stock sites are searched with them. Never invent private people. When the scene is abstract (greetings, opinions, "subscribe"), give atmospheric news b-roll keywords (e.g. "breaking news screen", "crowd city night", "world map digital").`}
Also choose "kind": "video" if moving footage suits the scene better, otherwise "image".
Target scene length about ${target} seconds (allowed ${Math.max(2, target * 0.5)} to ${target * 2}). Split only at sentence or clause boundaries.`;
  }

  /* تفريغ الصوت إلى مشاهد بتوقيتات */
  async function transcribe(buf, { target = 6, onProgress, signal } = {}) {
    onProgress?.('تجهيز الصوت…', 0);
    const chunks = await audioChunks(buf);
    const all = [];
    for (let i = 0; i < chunks.length; i++) {
      const c = chunks[i];
      onProgress?.(`تفريغ الجزء ${i + 1} من ${chunks.length}…`, i / chunks.length);
      const data = await b64(c.blob);
      const prompt = `You are the assistant of a video editor. Transcribe this narration audio exactly, word for word, in its ORIGINAL language and script (do not translate, keep Arabic dialect as spoken). This clip is ${c.dur.toFixed(1)} seconds long. Timestamps are in seconds from the start of THIS clip.
Split the transcript into consecutive scenes that cover the whole clip without gaps.
${guide(target)}
Return only JSON: {"scenes":[{"start":0.0,"end":5.2,"text":"...","keywords":["..."],"subject":"chicken","kind":"video"}]}`;
      const r = await call([{ inline_data: { mime_type: 'audio/wav', data } }, { text: prompt }], { signal });
      (r.scenes || []).forEach(x => {
        const st = Math.max(0, Math.min(c.dur, +x.start || 0)), en = Math.max(st, Math.min(c.dur, +x.end || st));
        if (String(x.text || '').trim()) all.push({ start: c.offset + st, end: c.offset + en, text: String(x.text).trim(), kw: clean([...[].concat(x.keywords || []), x.subject]), kind: x.kind === 'image' ? 'image' : 'video' });
      });
    }
    if (!all.length) throw new Error('لم يتعرّف Gemini على كلام في الملف');
    all.sort((a, b) => a.start - b.start);
    // اجعل المشاهد متصلة وتغطي كامل مدة الصوت
    for (let i = 0; i < all.length; i++) {
      all[i].start = i ? all[i - 1].end : 0;
      const next = all[i + 1]?.start ?? buf.duration;
      all[i].end = Math.max(all[i].start + 0.4, i === all.length - 1 ? buf.duration : Math.max(all[i].end, (all[i].end + next) / 2));
    }
    all[all.length - 1].end = Math.max(all[all.length - 1].end, buf.duration);
    onProgress?.('اكتمل التفريغ', 1);
    return all.map(x => ({ text: x.text, d: x.end - x.start, kw: x.kw, kind: x.kind }));
  }

  /* اقتراح كلمات بحث لنصوص مشاهد جاهزة */
  async function keywords(texts, { signal } = {}) {
    const out = [];
    for (let i = 0; i < texts.length; i += 40) {
      const part = texts.slice(i, i + 40);
      const prompt = `${guide(Settings.get().sceneTarget)}
Here are ${part.length} narration scenes (JSON array). Return JSON {"scenes":[{"keywords":["..."],"subject":"chicken","kind":"video"}]} with exactly ${part.length} items in the same order.
${JSON.stringify(part)}`;
      const r = await call([{ text: prompt }], { signal });
      part.forEach((_, k) => { const x = r.scenes?.[k] || {}; out.push({ kw: clean([...[].concat(x.keywords || []), x.subject]), kind: x.kind === 'image' ? 'image' : 'video' }); });
    }
    return out;
  }

  /* مواد النشر: سكربت الشورت، عنوان الصورة المصغرة، عنوان ووصف يوتيوب */
  async function promo(sceneTexts, { signal } = {}) {
    const s = Settings.get();
    const prompt = `You are a YouTube growth expert for ${Channel.cur.niche}. Channel context: ${s.context}.
Below is the narration of a new long video, split into numbered scenes (JSON array, index from 0).
Write, in ${Channel.cur.lang}:
1. "teaser": a 10-15 second voice-over script for a YouTube Short that makes viewers want to watch the full video. 25 to 38 words. Start with a strong hook (question or surprising fact from the video), do not reveal the full answer, end with an invitation to watch the full video on the channel.
2. "teaserScenes": 4 scene indexes whose visuals best fit the teaser, in order.
3. "thumbTitle": 2 to 4 punchy Arabic words (same language style) for the thumbnail (big text), no emojis. If the video compares two things use the form "X ولا Y؟".
4. "thumbScene": the scene index with the most eye-catching visual for the thumbnail.
4b. "thumbHighlight": the single most important word of thumbTitle (copied exactly) to highlight in color.
4c. "thumbLayout": "vs" if the video compares two things/options, otherwise "hero".
4e. "thumbPhrase": the 2-word Arabic phrase used in thumbPrompt.
4d. "thumbPrompt": a LONG professional ENGLISH prompt (150 to 220 words) for Google Flow / Imagen to create a click-worthy YouTube thumbnail, 16:9 landscape 1920x1080. Describe precisely: ${Channel.id === 'farm' ? 'the exact animal(s) and breed from the video (e.g. Egyptian baladi chickens, a white turkey), their expression and pose that tells the story of the video (curiosity, surprise, contrast, problem vs result), the setting (rural Egyptian farm, coop, field)' : 'the main subject of the news/trend (place, object, event, crowd) shown in the most dramatic way, the emotion of the story (shock, excitement, mystery, controversy), a cinematic news-style setting'}, a strong composition with one clear focal subject large in frame and the rule of thirds, camera (85mm lens, low angle or close-up, shallow depth of field), lighting (dramatic golden hour rim light, high contrast), color grading (vivid, saturated, warm vs cool contrast), a clean slightly blurred background and empty space on the right third. Include ONE short bold Arabic phrase of 2 words that summarizes the video (the same idea as thumbTitle), written exactly once inside double quotes, rendered as huge bold 3D Arabic letters with white fill, thick black outline and ${Channel.id === 'farm' ? 'yellow' : 'electric blue'} glow, placed on the right third. Add: "ultra realistic, 8k, sharp focus, professional YouTube thumbnail style, no logos, no watermark, no other text".
5. "ytTitle": a click-worthy, SEO-optimized YouTube title under 70 characters in Arabic (${Channel.cur.lang}). Put the main search keyword in the first words (what people type in YouTube search${Channel.id === 'farm' ? ', e.g. "تربية الفراخ البلدي"' : ', e.g. the name of the event, person, team or country'}), add curiosity, no clickbait lies, no emojis.
6. "description": a professional SEO YouTube description in Arabic (${Channel.cur.lang}, clear words people search for), 180 to 300 words, NO source credits, NO links. Structure:
   - First 2 lines (shown before "show more"): a strong hook sentence that contains the main keyword and a secondary keyword naturally.
   - A short paragraph explaining what the video covers, naturally repeating the main keyword 2-3 times and related long-tail keywords${Channel.id === 'farm' ? ' (e.g. تربية الدواجن في البيت، علف الفراخ البلدي، زيادة إنتاج البيض…)' : ' (e.g. names, places, dates and the trend keywords people search in Algeria and the Arab world)'}.
   - ${Channel.id === 'farm' ? '"في الفيديو ده هتعرف:"' : '"في هذا الفيديو:"'} followed by 4 to 6 bullet points starting with "✅".
   - A call to action to subscribe, like, turn on the bell, and comment with a question.
   Do NOT include hashtags or chapters inside "description" (they are added separately).
6b. "chapters": 4 to 7 YouTube chapters: [{"scene": index where the chapter starts, "title": short Arabic chapter title with keywords}]. The first chapter MUST start at scene 0.
6c. "keywords": 12 to 20 YouTube tags (search keywords) in Arabic and English, without "#", mixing short and long-tail phrases people really search.
7. "tags": 8 to 12 hashtags (Arabic and English), the 3 most important first, without spaces inside a tag (use _).
Return only JSON: {"teaser":"","teaserScenes":[0,1,2,3],"thumbTitle":"","thumbScene":0,"thumbHighlight":"","thumbLayout":"hero","thumbPrompt":"","thumbPhrase":"","ytTitle":"","description":"","chapters":[{"scene":0,"title":""}],"keywords":[""],"tags":["#..."]}
Scenes:
${JSON.stringify(sceneTexts.map(t => t.slice(0, 300)))}`;
    const r = await call([{ text: prompt }], { signal });
    const n = sceneTexts.length, idx = i => Math.max(0, Math.min(n - 1, parseInt(i) || 0));
    return {
      teaser: String(r.teaser || '').trim(),
      teaserScenes: (Array.isArray(r.teaserScenes) ? r.teaserScenes : []).map(idx).slice(0, 5),
      thumbTitle: String(r.thumbTitle || '').trim(),
      thumbScene: idx(r.thumbScene),
      thumbHighlight: String(r.thumbHighlight || '').trim(),
      thumbLayout: r.thumbLayout === 'vs' ? 'vs' : 'hero',
      thumbPrompt: String(r.thumbPrompt || '').trim(),
      thumbPhrase: String(r.thumbPhrase || '').trim(),
      ytTitle: String(r.ytTitle || '').trim(),
      description: String(r.description || '').trim(),
      chapters: (Array.isArray(r.chapters) ? r.chapters : []).map(c => ({ scene: idx(c.scene), title: String(c.title || '').trim() })).filter(c => c.title),
      keywords: (Array.isArray(r.keywords) ? r.keywords : String(r.keywords || '').split(/[,،]/)).map(k => String(k).replace(/^#/, '').trim()).filter(Boolean).slice(0, 25),
      tags: (Array.isArray(r.tags) ? r.tags : String(r.tags || '').split(/\s+/)).map(t => String(t).trim()).filter(Boolean).map(t => t.startsWith('#') ? t : '#' + t),
    };
  }

  /* يختار Gemini بالنظر أنسب صورة لكل مشهد، أو يرفض الكل.
     groups: [{text, subject, images:[base64 jpeg]}] → [رقم الصورة المختارة (يبدأ من 1) أو 0] */
  async function pickVisual(groups, { signal } = {}) {
    const s = Settings.get();
    const parts = [{ text: `You are the visual editor of ${Channel.cur.niche} (${s.context}).
For each scene below you get the narration and candidate stock images (thumbnails of photos or videos).
Choose the ONE candidate that best illustrates the narration and clearly shows the scene subject.
${Channel.id === 'farm' ? 'Reject a candidate if it shows: smoking or cigarettes, alcohol, drugs, weapons, violence, blood, nudity or sexy content, parties or nightlife, people as the main subject when the scene is about animals, city/office/technology scenes, text-heavy graphics, or anything unrelated to farming, animals or rural life.' : 'Reject a candidate if it shows: nudity or sexy content, gore or graphic violence, alcohol or drugs promotion, text-heavy graphics or watermarks, or anything unrelated to the narration topic. Prefer real places, people and objects that literally match the narration.'}
If no candidate is good, answer 0 for that scene.
Return only JSON: {"picks":[{"scene":1,"choice":2}]} with one item per scene, choice = candidate number (1-based) or 0.` }];
    groups.forEach((g, i) => {
      parts.push({ text: `\nScene ${i + 1} — subject: ${g.subject || (Channel.id === 'farm' ? 'farm animals' : 'the topic')} — narration: ${String(g.text).slice(0, 220)}` });
      g.images.forEach((b64, k) => { parts.push({ text: `Scene ${i + 1} candidate ${k + 1}:` }); parts.push({ inline_data: { mime_type: 'image/jpeg', data: b64 } }); });
    });
    const r = await call(parts, { signal });
    const out = groups.map(() => 0);
    (r.picks || []).forEach(p => { const i = (parseInt(p.scene) || 0) - 1, c = parseInt(p.choice) || 0; if (i >= 0 && i < out.length && c >= 0 && c <= groups[i].images.length) out[i] = c; });
    return out;
  }

  /* توليد صورة بالذكاء الاصطناعي (خلفية الصورة المصغرة) ← Blob */
  function findImage(o, depth = 0) {
    if (!o || typeof o !== 'object' || depth > 8) return null;
    const m = String(o.mime_type || o.mimeType || '');
    if (typeof o.data === 'string' && o.data.length > 2000 && (/image/.test(m) || !m)) return { data: o.data, mime: m || 'image/jpeg' };
    for (const v of Array.isArray(o) ? o : Object.values(o)) { const r = findImage(v, depth + 1); if (r) return r; }
    return null;
  }
  async function image(prompt, { signal, aspect = '16:9' } = {}) {
    const s = Settings.get();
    if (!s.keys.gemini) throw new Error('أضف مفتاح Gemini من الإعدادات أولاً');
    const key = s.keys.gemini.trim(), headers = { 'Content-Type': 'application/json', 'x-goog-api-key': key };
    const models = [...new Set([s.imageModel || 'gemini-nano-banana-2.1', 'gemini-3.1-flash-lite-image', 'gemini-3.1-flash-image', 'gemini-2.5-flash-image'])];
    let lastErr = 'تعذّر توليد الصورة';
    for (const model of models) {
      for (let a = 0; a < 2; a++) {
        let r = await fetch(API.replace('models/', '') + 'interactions', { method: 'POST', signal, headers, body: JSON.stringify({
          model, input: [{ type: 'text', text: prompt }],
          response_format: { type: 'image', mime_type: 'image/jpeg', aspect_ratio: aspect, image_size: '1K' } }) });
        let d = await r.json().catch(() => ({}));
        if (!r.ok && (r.status === 400 || r.status === 404)) {
          r = await fetch(API + encodeURIComponent(model) + ':generateContent', { method: 'POST', signal, headers, body: JSON.stringify({
            contents: [{ role: 'user', parts: [{ text: prompt }] }],
            generationConfig: { responseModalities: ['IMAGE', 'TEXT'], imageConfig: { aspectRatio: aspect } } }) });
          d = await r.json().catch(() => ({}));
        }
        if (r.ok) {
          const im = findImage(d);
          if (im) { const bin = atob(im.data), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return new Blob([u], { type: im.mime }); }
          lastErr = 'لم يُرجع Gemini صورة (ربما رُفض الوصف)'; break;
        }
        const zero = /limit:\s*0|free_tier|FreeTier/i.test(JSON.stringify(d));
        if (r.status === 429 && zero) throw new Error('حسابك المجاني في Google AI Studio لا يسمح بتوليد الصور (الحد صفر). استخدم Google Flow');
        if (r.status === 429 && a === 0) { await sleep(6000); continue; }
        lastErr = r.status === 429 ? 'تجاوزت حد توليد الصور حالياً، أو يحتاج حسابك تفعيل الفوترة في Google AI Studio'
          : r.status === 403 ? 'مفتاحك لا يملك صلاحية توليد الصور' : errMsg(r.status, d);
        break;
      }
    }
    throw new Error(lastErr);
  }

  /* خطة الريل التشويقي: أقوى مقطع متصل من التعليق + عنوان خطّاف + لقطات جديدة */
  async function reelPlan(scenes, { signal } = {}) {
    const s = Settings.get();
    const prompt = `You edit YouTube Shorts teasers for ${Channel.cur.niche} (${s.context}). Language: ${Channel.cur.lang}.
Below are the narration scenes of the long video with their duration in seconds (JSON, index from 0).
1. Pick "start" and "end": a CONSECUTIVE range of scenes, total 12 to 30 seconds, made of COMPLETE sentences, that works as a teaser on its own: it raises curiosity (a question, a surprising fact, a problem or a promise) and does not give the full answer. Never start in the middle of an idea.
2. "hook": 2 to 5 punchy Arabic words (same language style) shown on screen in the first 2 seconds. No emojis.
3. "cta": a short Arabic sentence (same language style) for the end card inviting to watch the full video below (max 7 words), e.g. "${Channel.id === 'farm' ? 'الفيديو كامل تحت، ادخل شوفه' : 'القصة الكاملة في الفيديو تحت'}".
Return only JSON: {"start":0,"end":2,"hook":"","cta":""}
Scenes:
${JSON.stringify(scenes.map(x => ({ d: +x.d.toFixed(1), text: x.text.slice(0, 260) })))}`;
    const r = await call([{ text: prompt }], { signal });
    const n = scenes.length, clamp = v => Math.max(0, Math.min(n - 1, parseInt(v) || 0));
    const a = clamp(r.start), b = Math.max(a, clamp(r.end));
    return { start: a, end: b, hook: String(r.hook || '').trim(), cta: String(r.cta || '').trim() || 'الفيديو كامل تحت، ادخل شوفه' };
  }

  /* مرور المونتير: يختار اللحظات المهمة ويقترح نصاً قصيراً احترافياً لكل منها */
  async function editorial(scenes, { signal } = {}) {
    const total = scenes.reduce((a, s) => a + s.d, 0), max = Math.max(3, Math.round(total / 20));
    const prompt = `You are a professional YouTube video editor for ${Channel.cur.niche}. Language: ${Channel.cur.lang}.
Below are the narration scenes (JSON, index from 0, with start time and duration in seconds).
Choose ONLY the most important moments that deserve on-screen text like a pro editor would do: key facts, surprising info, numbers, practical tips, warnings, and rhetorical questions. Do NOT caption everything. At most ${max} moments, spaced at least 15 seconds apart, never on scenes shorter than 2.5 seconds.
For each moment give:
- "scene": index
- "type": one of "key" (important sentence), "question", "number" (a number/stat/duration/price), "tip", "warn"
- "text": a SHORT punchy Arabic phrase in the same language style (max 7 words) derived from the narration, not a full sentence copy. For "question" end with "؟". For "number" start with the number and unit (e.g. "21 يوم", "3 وجبات").
- "emph": for "key", the single most important word from "text" (copied exactly); otherwise "".
- "sub": for "number", a 2-5 word label explaining the number; otherwise "".
Return only JSON: {"fx":[{"scene":0,"type":"key","text":"","emph":"","sub":""}]}
Scenes:
${JSON.stringify((() => { let t = 0; return scenes.map(s => { const o = { start: +t.toFixed(1), d: +s.d.toFixed(1), text: s.text.slice(0, 240) }; t += s.d; return o; }); })())}`;
    const r = await call([{ text: prompt }], { signal });
    const ok = ['key', 'question', 'number', 'tip', 'warn'];
    return (Array.isArray(r.fx) ? r.fx : []).map(f => ({ scene: parseInt(f.scene), type: ok.includes(f.type) ? f.type : 'key', text: String(f.text || '').trim(), emph: String(f.emph || '').trim(), sub: String(f.sub || '').trim() }))
      .filter(f => f.text && f.scene >= 0 && f.scene < scenes.length);
  }

  /* اختبار المفتاح: يرجع اسم النموذج الذي نجح */
  async function test() {
    const { model } = await send(TEXT_MODELS(), m => ({ url: API + encodeURIComponent(m) + ':generateContent', body: { contents: [{ role: 'user', parts: [{ text: 'Reply with OK' }] }] } }), { gap: 0 });
    return model;
  }

  const clean = k => [...new Set((Array.isArray(k) ? k : String(k || '').split(',')).map(x => String(x).trim()).filter(Boolean))].slice(0, 6);

  return { call, transcribe, keywords, promo, pickVisual, image, reelPlan, editorial, test, send, errMsg, quotaInfo };
})();
